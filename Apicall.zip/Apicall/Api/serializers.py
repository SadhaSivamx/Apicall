from rest_framework import serializers
from Api.models import Person
class Serialize(serializers.ModelSerializer):
    class Meta:
        model=Person
        fields='__all__'