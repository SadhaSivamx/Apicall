from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from Api.serializers import Serialize
from Api.models import Person
# Create your views here.
@api_view(['GET'])
def Showcase(request):
    mydata = Person.objects.all()
    mydata=Serialize(mydata,many=True)
    return Response(mydata.data)