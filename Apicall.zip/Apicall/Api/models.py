from django.db import models

# Create your models here.
class Person(models.Model):
    Name = models.CharField(max_length = 20)
    Age = models.CharField(max_length = 3)
    Dob = models.CharField(max_length = 10)